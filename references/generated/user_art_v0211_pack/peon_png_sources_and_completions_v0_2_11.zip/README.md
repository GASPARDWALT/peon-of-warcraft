# PNG v0.2.11

Ouvrez index.html pour la galerie. references/characters contient les sources originales. references/generated contient les compléments natifs, leurs manifestes et les captures du jeu. Les previews agrandies sont distinctes des sprites natifs. Les palettes et tailles de conversion dans la ROM sont décrites dans docs/USER_ART_V0211.md.
